package com.perfil;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PerfilApplicationTests {

	@Test
	void contextLoads() {
	}

}
