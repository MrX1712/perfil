package com.perfil.controller;

import com.perfil.model.*;
import com.perfil.service.UsuarioService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;

@Controller
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    /**
     * Exibe a página principal com o formulário integrado
     */
    @GetMapping("/")
    public String mostrarFormulario(Model model) {
        model.addAttribute("questionarioForm", new QuestionarioForm());
        return "formulario"; // Retorna o arquivo HTML único
    }

    /**
     * Processa o formulário via POST (para manter compatibilidade com Thymeleaf)
     * Redireciona para a mesma página com os dados do resultado
     */
    @PostMapping("/processar")
    public String processarFormulario(@Valid @ModelAttribute QuestionarioForm questionarioForm,
                                      BindingResult result,
                                      Model model) {
        if (result.hasErrors()) {
            return "formulario";
        }

        Usuario usuario = usuarioService.processarQuestionario(questionarioForm);
        model.addAttribute("usuario", usuario);
        model.addAttribute("mostrarResultado", true);
        return "formulario"; // Retorna o mesmo template com dados do resultado
    }

    /**
     * Endpoint REST para processar o questionário via AJAX (JavaScript)
     * Retorna JSON com o resultado do perfil
     */
    @PostMapping("/api/processar")
    @ResponseBody
    public ResponseEntity<?> processarQuestionarioAjax(@RequestBody QuestionarioForm questionarioForm) {
        try {
            Usuario usuario = usuarioService.processarQuestionario(questionarioForm);

            // Criar resposta JSON com dados do resultado
            ResultadoResponse response = new ResultadoResponse();
            response.setNome(usuario.getNome());
            response.setEmail(usuario.getEmail());
            response.setPerfil(usuario.getPerfil().getNome());
            response.setSuccess(true);

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            ErrorResponse error = new ErrorResponse();
            error.setSuccess(false);
            error.setMessage("Erro ao processar questionário: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    /**
     * Endpoint para obter detalhes de um perfil específico
     */
    @GetMapping("/api/perfil/{nomePerfil}")
    @ResponseBody
    public ResponseEntity<?> obterDetalhesPerfil(@PathVariable String nomePerfil) {
        try {
            var detalhes = usuarioService.obterDetalhesPerfilPorNome(nomePerfil);
            return ResponseEntity.ok(detalhes);
        } catch (Exception e) {
            ErrorResponse error = new ErrorResponse();
            error.setSuccess(false);
            error.setMessage("Perfil não encontrado: " + nomePerfil);
            return ResponseEntity.notFound().build();
        }
    }

    // Classes internas para as respostas JSON
    public static class ResultadoResponse {
        private boolean success;
        private String nome;
        private String email;
        private String perfil;

        // Getters e Setters
        public boolean isSuccess() { return success; }
        public void setSuccess(boolean success) { this.success = success; }

        public String getNome() { return nome; }
        public void setNome(String nome) { this.nome = nome; }

        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }

        public String getPerfil() { return perfil; }
        public void setPerfil(String perfil) { this.perfil = perfil; }
    }

    public static class ErrorResponse {
        private boolean success;
        private String message;

        // Getters e Setters
        public boolean isSuccess() { return success; }
        public void setSuccess(boolean success) { this.success = success; }

        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
    }
}