package com.perfil.service;

import com.perfil.model.*;
import com.perfil.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private PerfilRepository perfilRepository;

    public Usuario processarQuestionario(QuestionarioForm form) {

        // Mapeamento dos perfis conforme a tabela de evolução
        Map<Character, String> perfilMap = new HashMap<>();
        perfilMap.put('A', "Minimal");
        perfilMap.put('B', "Sofisticado I");
        perfilMap.put('C', "Sofisticado II");
        perfilMap.put('D', "Sofisticado III");

        // Contagem das respostas
        Map<Character, Integer> contagem = new HashMap<>();
        contagem.put('A', 0);
        contagem.put('B', 0);
        contagem.put('C', 0);
        contagem.put('D', 0);

        // Array com todas as respostas do questionário
        Character[] respostas = {
                form.getQuestao1(),
                form.getQuestao2(),
                form.getQuestao3(),
                form.getQuestao4(),
                form.getQuestao5()
        };

        // Contabilizar as respostas
        for (Character resposta : respostas) {
            if (resposta != null && contagem.containsKey(resposta)) {
                contagem.put(resposta, contagem.get(resposta) + 1);
            }
        }

        // Determinar o perfil vencedor (resposta mais frequente)
        Character perfilVencedor = 'A'; // Default para Minimal
        int maxCount = 0;

        // Verificar qual resposta teve mais ocorrências
        // Ordem de prioridade: D > C > B > A (em caso de empate, perfil mais avançado ganha)
        for (Character key : Arrays.asList('D', 'C', 'B', 'A')) {
            if (contagem.get(key) >= maxCount) {
                maxCount = contagem.get(key);
                perfilVencedor = key;
            }
        }

        // Buscar o perfil correspondente no banco
        String nomePerfil = perfilMap.get(perfilVencedor);
        Perfil perfil = perfilRepository.findByNome(nomePerfil)
                .orElseThrow(() -> new RuntimeException("Perfil não encontrado: " + nomePerfil));

        // Verificar se já existe usuário com este email
        Optional<Usuario> usuarioExistente = usuarioRepository.findByEmail(form.getEmail());

        Usuario usuario;
        if (usuarioExistente.isPresent()) {
            // Atualizar usuário existente
            usuario = usuarioExistente.get();
            usuario.setNome(form.getNome());
            usuario.setPerfil(perfil);
        } else {
            // Criar novo usuário
            usuario = new Usuario(form.getNome(), form.getEmail(), perfil);
        }

        return usuarioRepository.save(usuario);
    }

    /**
     * Método auxiliar para obter detalhes do perfil
     * Pode ser usado para endpoints adicionais da API
     */
    public Map<String, Object> obterDetalhesPerfilPorNome(String nomePerfil) {
        Map<String, Object> detalhes = new HashMap<>();

        switch (nomePerfil) {
            case "Minimal":
                detalhes.put("habilidades", Arrays.asList(
                        "Construir disciplina de aportes",
                        "Compreender a lógica Barbell (proteção + crescimento)",
                        "Entender o conceito de risco assimétrico"
                ));
                detalhes.put("acoesPraticas", Arrays.asList(
                        "Criar reserva de emergência",
                        "Montar carteira inicial com Tesouro Selic + ETFs simples",
                        "Simular primeiros aportes em renda variável sem operar ainda"
                ));
                detalhes.put("mentalidade", "Preservar capital é parte da vitória. Errar pequeno é melhor do que errar grande.");
                detalhes.put("metaEvolucao", "Evoluir para Sofisticado Nível I com gestão básica de risco e primeira exposição ativa.");
                break;

            case "Sofisticado I":
                detalhes.put("habilidades", Arrays.asList(
                        "Aprender Balanceamento Dinâmico básico",
                        "Usar seguro de carteira com opções",
                        "Melhorar capacidade de identificar ativos de valor"
                ));
                detalhes.put("acoesPraticas", Arrays.asList(
                        "Balancear carteira trimestralmente",
                        "Operar opções simples (estratégia do Pozinho)",
                        "Iniciar análise de ações para value investing básico"
                ));
                detalhes.put("mentalidade", "Volatilidade é amiga de quem sabe usar. A consistência constrói o capital.");
                detalhes.put("metaEvolucao", "Evoluir para Sofisticado Nível II com geração de renda e melhor timing de aportes.");
                break;

            case "Sofisticado II":
                detalhes.put("habilidades", Arrays.asList(
                        "Gerar renda recorrente com Dividendo Sintético",
                        "Incluir ativos de proteção estrutural (ouro, commodities, cripto)",
                        "Ajustar Barbell com mais precisão de timing macro"
                ));
                detalhes.put("acoesPraticas", Arrays.asList(
                        "Operar opções para geração de renda",
                        "Balancear carteira mensalmente conforme volatilidade",
                        "Acompanhar indicadores macroeconômicos simples"
                ));
                detalhes.put("mentalidade", "Ganhar na normalidade e explodir no caos. Cada passo agora exige inteligência de portfólio.");
                detalhes.put("metaEvolucao", "Evoluir para Sofisticado Nível III dominando estratégias de convexidade máxima.");
                break;

            case "Sofisticado III":
                detalhes.put("habilidades", Arrays.asList(
                        "Operar estratégias avançadas de opções (LIPS, Tesourinha, Bigodon, TIC-TAC)",
                        "Balanceamento Dinâmico semanal",
                        "Simetrizar portfólio com timing e optionalidade"
                ));
                detalhes.put("acoesPraticas", Arrays.asList(
                        "Executar operações estruturadas de opções",
                        "Manter gestão ativa (monitoramento + rebalanceamento semanal)",
                        "Refinar timing macro para proteger e alavancar simultaneamente"
                ));
                detalhes.put("mentalidade", "Investir é construir antifragilidade. O mercado é meu aliado, não meu inimigo.");
                detalhes.put("metaEvolucao", "Consolidar-se como Investidor Roxedo com retorno geométrico acima da média.");
                break;

            default:
                detalhes.put("erro", "Perfil não reconhecido");
        }

        return detalhes;
    }
}