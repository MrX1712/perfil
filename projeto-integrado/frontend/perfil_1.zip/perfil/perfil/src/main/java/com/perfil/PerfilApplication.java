package com.perfil;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PerfilApplication {
	public static void main(String[] args) {
		SpringApplication.run(PerfilApplication.class, args);
	}
}
