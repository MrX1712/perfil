package com.perfil.model;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class QuestionarioForm {
    @NotBlank(message = "Nome é obrigatório")
    private String nome;

    @NotBlank(message = "Email é obrigatório")
    @Email(message = "Email deve ser válido")
    private String email;

    @NotNull(message = "Resposta da questão 1 é obrigatória")
    private Character questao1;

    @NotNull(message = "Resposta da questão 2 é obrigatória")
    private Character questao2;

    @NotNull(message = "Resposta da questão 3 é obrigatória")
    private Character questao3;

    @NotNull(message = "Resposta da questão 4 é obrigatória")
    private Character questao4;

    @NotNull(message = "Resposta da questão 5 é obrigatória")
    private Character questao5;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Character getQuestao1() {
        return questao1;
    }

    public void setQuestao1(Character questao1) {
        this.questao1 = questao1;
    }

    public Character getQuestao2() {
        return questao2;
    }

    public void setQuestao2(Character questao2) {
        this.questao2 = questao2;
    }

    public Character getQuestao3() {
        return questao3;
    }

    public void setQuestao3(Character questao3) {
        this.questao3 = questao3;
    }

    public Character getQuestao4() {
        return questao4;
    }

    public void setQuestao4(Character questao4) {
        this.questao4 = questao4;
    }

    public Character getQuestao5() {
        return questao5;
    }

    public void setQuestao5(Character questao5) {
        this.questao5 = questao5;
    }
}