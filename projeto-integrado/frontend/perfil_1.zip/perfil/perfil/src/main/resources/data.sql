INSERT INTO perfis (nome, nivel) VALUES ('Minimal', 1);
INSERT INTO perfis (nome, nivel) VALUES ('Sofisticado I', 2);
INSERT INTO perfis (nome, nivel) VALUES ('Sofisticado II', 3);
INSERT INTO perfis (nome, nivel) VALUES ('Sofisticado III', 4);